This firmware fixes the following issues:

- Solve a Sitecom Cloud Security activation issue.
- Fixed some security issues.

To install this firmware, follow the steps below:

1. Unzip all files to a folder.
2. Login to the webinterface of the modem via http://192.168.0.1 with username: admin. The password can be found on the backlabel of the modem.
3. Navigate to Toolbox/Firmware Upgrade
4. Browse to the BIN file and press upgrade.
5. You'll see a notification that the file has been uploaded and the upgrade will start. 
Please wait for the upgrade to finish. Do not power off the device untill the login popup shows up again!